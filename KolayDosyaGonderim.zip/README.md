# Kolay Dosya Gönderim

Android TV uygulaması. Aynı Wi-Fi ağındaki iPhone / iPad / Android telefondan
TV'ye dosya göndermeyi sağlar. Telefon tarafında uygulama gerekmez.

## Adresler

Sunucu **sabit 8080 portunda** çalışır (port meşguse TV ekranında uyarı çıkar).

- **IP adresi** — `http://192.168.x.x:8080` — her koşulda çalışır, QR kod bunu taşır.
- **Sabit adres** — `http://kolaydosya.local:8080` — yalnızca mDNS yayını
  gerçekten duyurulabildiyse ekranda ana adres olarak gösterilir.

mDNS başarısızsa (bazı modemler multicast trafiğini engeller, ya da ağda isim
çakışması vardır) ekranda ana adres IP olarak kalır ve hatanın kısa açıklaması
yazılır. Dosya gönderimi bu durumda da IP üzerinden çalışmaya devam eder.

## Kullanım
1. TV'de uygulamayı aç. Ekranda adres ve QR kod çıkar.
2. iPhone kamerasını QR koda tut, açılan sayfadan dosya seç → "TV'ye Gönder".
3. Dosya TV'deki "Gelen Dosyalar" listesine düşer.
4. Kumandayla satırı seç; sağ/sol ile **Aç/Kur** ve **Sil** butonları arasında geç, OK ile uygula.

Dosyalar TV'de **İndirilenler / KolayDosya** klasörüne kaydedilir.

## Paylaş menüsünden gönderme (iPhone)
Safari sayfasının altındaki **Kestirmeyi Kur** bağlantısıyla Apple Kestirmesi eklenir.
Kestirme ayarları:

- Yöntem: `POST`
- İstek Gövdesi: `Form`
- Alan adı: `file`
- Değer: `Kestirme Girişi`
- Adres: `http://kolaydosya.local:8080/upload`

`.local` adresi ancak TV ekranında "Sabit adres hazır" yazıyorsa çalışır.
Çalışmıyorsa kestirmedeki adresi TV'nin IP'siyle değiştir.

## APK üretimi
GitHub'a push et → Actions → "Build APK" → Artifacts altından
`KolayDosyaGonderim-APK` indir.

## Teknik
- Kotlin, View mimarisi, minSdk 23, targetSdk 34
- NanoHTTPD 2.3.1, ZXing (QR), JmDNS 3.6.3 (mDNS), RecyclerView
- IP tespiti ConnectivityManager + LinkProperties ile (VPN/loopback/link-local hariç),
  ağ değişimleri NetworkCallback ile izlenir
- Android 10+ MediaStore, altı için FileProvider
