package com.tvdosya.receiver

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import java.io.File
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.net.Inet4Address

class MainActivity : AppCompatActivity() {

    private var server: FileServer? = null
    private var mdns: MdnsPublisher? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var currentIp: String? = null
    private lateinit var tvUrl: TextView
    private lateinit var tvUrlAlt: TextView
    private lateinit var tvConn: TextView
    private lateinit var ivQr: ImageView
    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private lateinit var adapter: FileAdapter

    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        tvUrl = findViewById(R.id.tvUrl)
        tvUrlAlt = findViewById(R.id.tvUrlAlt)
        tvConn = findViewById(R.id.tvConn)
        ivQr = findViewById(R.id.ivQr)
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)

        adapter = FileAdapter(
            ReceivedStore.load(this),
            onAction = { open(it) },
            onDelete = { askDelete(it) }
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.clipToPadding = false
        list.clipChildren = false
        list.isVerticalScrollBarEnabled = false
        updateEmpty()

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),
                1
            )
        }
        startServer()
    }

    private fun startServer() {
        val ip = activeIpv4()
        if (ip == null) {
            showNoNetwork()
            return
        }
        try {
            val srv = FileServer(applicationContext, FileServer.PORT) { f -> onFile(f) }
            srv.start(0, true)
            server = srv
        } catch (_: Exception) {
            tvConn.text = getString(R.string.port_error)
            tvUrl.text = getString(R.string.port_busy)
            tvUrlAlt.text = getString(R.string.port_busy_hint)
            return
        }
        currentIp = ip
        applyIpUi(ip)
        showQr(ipUrl(ip))

        if (mdns == null) mdns = MdnsPublisher(applicationContext) { onMdnsState(it) }
        mdns?.refresh(ip, FileServer.PORT)
        registerNetworkCallback()
    }

    private fun ipUrl(ip: String) = "http://$ip:${FileServer.PORT}"

    private fun showNoNetwork() {
        tvConn.text = getString(R.string.conn_off)
        tvUrl.text = getString(R.string.no_network)
        tvUrlAlt.text = ""
    }

    /** mDNS henüz hazır değilken ekranda IP adresi ana adrestir. */
    private fun applyIpUi(ip: String) {
        tvConn.text = getString(R.string.conn_ip)
        tvUrl.text = ipUrl(ip)
        tvUrlAlt.text = getString(R.string.mdns_starting)
    }

    private fun onMdnsState(state: MdnsPublisher.State) {
        val ip = currentIp ?: return
        when (state) {
            is MdnsPublisher.State.Starting -> {
                tvConn.text = getString(R.string.conn_ip)
                tvUrl.text = ipUrl(ip)
                tvUrlAlt.text = getString(R.string.mdns_starting)
            }
            is MdnsPublisher.State.Ready -> {
                tvConn.text = getString(R.string.conn_mdns_ready)
                tvUrl.text = "http://${MdnsPublisher.LOCAL_NAME}:${FileServer.PORT}"
                tvUrlAlt.text = getString(R.string.alt_address, ipUrl(ip))
            }
            is MdnsPublisher.State.Error -> {
                tvConn.text = getString(R.string.conn_ip)
                tvUrl.text = ipUrl(ip)
                tvUrlAlt.text = getString(R.string.mdns_failed, state.message)
            }
        }
    }

    /** Aktif Wi-Fi/Ethernet ağının IPv4 adresi; VPN, loopback ve link-local hariç. */
    private fun activeIpv4(): String? {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
        val net = cm.activeNetwork ?: return null
        return ipv4Of(cm, net)
    }

    private fun ipv4Of(cm: ConnectivityManager, net: Network): String? {
        val caps: NetworkCapabilities = cm.getNetworkCapabilities(net) ?: return null
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return null
        val usable = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        if (!usable) return null

        val props: LinkProperties = cm.getLinkProperties(net) ?: return null
        for (la in props.linkAddresses) {
            val addr = la.address
            if (addr is Inet4Address &&
                !addr.isLoopbackAddress &&
                !addr.isLinkLocalAddress &&
                !addr.isAnyLocalAddress
            ) {
                return addr.hostAddress
            }
        }
        return null
    }

    private fun registerNetworkCallback() {
        if (netCallback != null) return
        val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                ui.post { onNetworkChanged() }
            }

            override fun onLost(network: Network) {
                ui.post { onNetworkChanged() }
            }

            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) {
                ui.post { onNetworkChanged() }
            }
        }
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
            .build()
        try {
            cm.registerNetworkCallback(req, cb)
            netCallback = cb
        } catch (_: Exception) {
        }
    }

    /** IP değişirse QR, yedek adres ve mDNS yayını tazelenir. */
    private fun onNetworkChanged() {
        val ip = activeIpv4()
        if (ip == null) {
            currentIp = null
            mdns?.stop()
            showNoNetwork()
            return
        }
        if (ip == currentIp) return
        currentIp = ip
        applyIpUi(ip)
        showQr(ipUrl(ip))
        mdns?.refresh(ip, FileServer.PORT)
    }

    private fun onFile(f: ReceivedFile) {
        ReceivedStore.add(applicationContext, f)
        ui.post {
            adapter.addFirst(f)
            list.scrollToPosition(0)
            updateEmpty()
            Toast.makeText(this, "${f.name} alındı", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateEmpty() {
        val hasItems = adapter.itemCount > 0
        empty.visibility = if (hasItems) View.GONE else View.VISIBLE
        list.visibility = if (hasItems) View.VISIBLE else View.GONE
        if (hasItems && !list.hasFocus()) {
            list.post { list.requestFocus() }
        }
    }

    /** OK tuşuna basılı tutunca çıkan silme menüsü. */
    private fun askDelete(f: ReceivedFile) {
        AlertDialog.Builder(this, R.style.DialogTheme)
            .setTitle(f.name)
            .setMessage(getString(R.string.delete_msg))
            .setPositiveButton(R.string.delete_file) { _, _ -> delete(f, true) }
            .setNeutralButton(R.string.delete_entry) { _, _ -> delete(f, false) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun delete(f: ReceivedFile, alsoFile: Boolean) {
        if (alsoFile) {
            try {
                if (f.path.isNotEmpty()) {
                    File(f.path).delete()
                } else if (f.uri.isNotEmpty()) {
                    contentResolver.delete(Uri.parse(f.uri), null, null)
                }
            } catch (_: Exception) {
            }
        }
        adapter.remove(f)
        ReceivedStore.save(applicationContext, adapter.snapshot())
        updateEmpty()
        Toast.makeText(this, R.string.deleted, Toast.LENGTH_SHORT).show()
    }

    private fun open(f: ReceivedFile) {
        if (f.uri.isEmpty()) {
            Toast.makeText(this, R.string.cant_open, Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri = Uri.parse(f.uri)
            val mime = if (f.kind == ReceivedFile.Kind.APK)
                "application/vnd.android.package-archive" else mimeOf(f.ext)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, R.string.cant_open, Toast.LENGTH_LONG).show()
        }
    }

    private fun mimeOf(ext: String): String = when (ext) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        else -> "*/*"
    }

    private fun showQr(text: String) {
        try {
            val size = 460
            val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
            for (x in 0 until size) {
                for (y in 0 until size) {
                    bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            ivQr.setImageBitmap(bmp)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        netCallback?.let { cb ->
            runCatching {
                (getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager)
                    ?.unregisterNetworkCallback(cb)
            }
        }
        netCallback = null
        mdns?.shutdown()
        mdns = null
        server?.stop()
        server = null
        super.onDestroy()
    }
}
