package com.tvdosya.receiver

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ReceivedFile(
    val name: String,
    val size: Long,
    val time: Long,
    val uri: String,
    val path: String = ""
) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()

    val kind: Kind
        get() = when (ext) {
            "apk" -> Kind.APK
            "mp4", "mkv", "avi", "mov", "webm", "m4v" -> Kind.VIDEO
            "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> Kind.IMAGE
            "pdf" -> Kind.PDF
            "mp3", "wav", "m4a", "flac", "aac", "ogg" -> Kind.AUDIO
            else -> Kind.OTHER
        }

    enum class Kind { APK, VIDEO, IMAGE, PDF, AUDIO, OTHER }

    fun humanSize(): String = when {
        size < 1024 -> "$size B"
        size < 1048576 -> "${size / 1024} KB"
        size < 1073741824L -> String.format(Locale("tr"), "%.1f MB", size / 1048576.0)
        else -> String.format(Locale("tr"), "%.1f GB", size / 1073741824.0)
    }

    fun humanTime(): String {
        val tr = Locale("tr", "TR")
        val hm = SimpleDateFormat("HH:mm", tr).format(Date(time))
        val now = Calendar.getInstance()
        val then = Calendar.getInstance()
        then.timeInMillis = time
        val sameDay = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        now.add(Calendar.DAY_OF_YEAR, -1)
        val yesterday = now.get(Calendar.YEAR) == then.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)
        return when {
            sameDay -> "Bugün $hm"
            yesterday -> "Dün $hm"
            else -> SimpleDateFormat("d MMM HH:mm", tr).format(Date(time))
        }
    }
}

object ReceivedStore {
    private const val PREF = "tvdosya"
    private const val KEY = "files"
    private const val MAX = 60

    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<ReceivedFile> {
        val out = ArrayList<ReceivedFile>()
        try {
            val arr = JSONArray(prefs(c).getString(KEY, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    ReceivedFile(
                        o.getString("n"),
                        o.getLong("s"),
                        o.getLong("t"),
                        o.optString("u", ""),
                        o.optString("p", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun add(c: Context, f: ReceivedFile): MutableList<ReceivedFile> {
        val list = load(c)
        list.add(0, f)
        while (list.size > MAX) list.removeAt(list.size - 1)
        save(c, list)
        return list
    }

    fun save(c: Context, list: List<ReceivedFile>) {
        val arr = JSONArray()
        for (f in list) {
            arr.put(
                JSONObject()
                    .put("n", f.name)
                    .put("s", f.size)
                    .put("t", f.time)
                    .put("u", f.uri)
                    .put("p", f.path)
            )
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply()
    }
}
