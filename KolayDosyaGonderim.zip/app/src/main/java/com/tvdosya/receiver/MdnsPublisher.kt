package com.tvdosya.receiver

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import javax.jmdns.JmDNS
import javax.jmdns.ServiceInfo
import javax.jmdns.impl.JmDNSImpl

/**
 * Cihazı yerel ağda "kolaydosya.local" adıyla yayımlar.
 * Yayının gerçekten duyurulduğu doğrulanır; hatalar yutulmaz, [State] ile bildirilir.
 */
class MdnsPublisher(
    context: Context,
    private val onState: (State) -> Unit
) {

    sealed class State {
        object Starting : State()
        data class Ready(val hostName: String) : State()
        data class Error(val message: String) : State()
    }

    companion object {
        const val HOST = "kolaydosya"
        const val LOCAL_NAME = "kolaydosya.local"
        private const val SERVICE_TYPE = "_http._tcp.local."
        private const val SERVICE_NAME = "Kolay Dosya Gönderim"
        private const val ANNOUNCE_TIMEOUT_MS = 6000L
    }

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    /** Her start() yeni bir kuşak alır; eski görevlerin sonucu yok sayılır. */
    private val generation = AtomicInteger(0)

    private var jmDNS: JmDNS? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    @Volatile
    var publishedIp: String? = null
        private set

    /** Aynı IP için yayın zaten hazırsa hiçbir şey yapmaz. */
    fun refresh(ip: String?, port: Int = FileServer.PORT) {
        if (ip == null) {
            stop()
            return
        }
        if (ip == publishedIp && jmDNS != null) return
        start(ip, port)
    }

    fun start(ipAddress: String, port: Int = FileServer.PORT) {
        val myGen = generation.incrementAndGet()
        publishedIp = null
        emit(myGen, State.Starting)

        executor.execute {
            if (myGen != generation.get()) return@execute
            teardown()

            try {
                acquireLock()

                val jm = JmDNS.create(InetAddress.getByName(ipAddress), HOST)
                jmDNS = jm
                if (myGen != generation.get()) {
                    teardown()
                    return@execute
                }

                val info = ServiceInfo.create(SERVICE_TYPE, SERVICE_NAME, port, "path=/")
                jm.registerService(info)

                // Yayının ağa gerçekten duyurulmasını bekle.
                // JmDNS'in public arayüzünde waitForAnnounced yok; uygulama sınıfında var.
                // Doğrulanamıyorsa başarısız say: çalışmayan .local adresi "hazır" gösterilmesin.
                val announced = runCatching {
                    (jm as? JmDNSImpl)?.waitForAnnounced(ANNOUNCE_TIMEOUT_MS) ?: false
                }.getOrDefault(false)
                if (!announced) {
                    throw IOException("mDNS duyurusu doğrulanamadı veya zaman aşımına uğradı")
                }
                if (myGen != generation.get()) {
                    teardown()
                    return@execute
                }

                val published = jm.hostName?.trimEnd('.') ?: ""
                if (!published.equals(LOCAL_NAME, ignoreCase = true)) {
                    // Çakışma yüzünden kolaydosya-2.local gibi bir ad üretilmiş olabilir;
                    // bu durumda sabit adres güvenilir değildir.
                    teardown()
                    emit(myGen, State.Error("ağda isim çakışması: $published"))
                    return@execute
                }

                publishedIp = ipAddress
                emit(myGen, State.Ready(published))
            } catch (e: Exception) {
                teardown()
                emit(myGen, State.Error(e.message ?: e.javaClass.simpleName))
            }
        }
    }

    fun stop() {
        generation.incrementAndGet()
        executor.execute { teardown() }
    }

    /** Activity kapanırken: servisleri kaldır, JmDNS'i kapat, kilidi bırak, executor'ı durdur. */
    fun shutdown() {
        generation.incrementAndGet()
        executor.execute { teardown() }
        executor.shutdown()
    }

    private fun acquireLock() {
        val wifiManager = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        multicastLock = wifiManager
            ?.createMulticastLock("kolaydosya-mdns")
            ?.apply {
                setReferenceCounted(false)
                acquire()
            }
    }

    private fun teardown() {
        publishedIp = null
        jmDNS?.let { jm ->
            runCatching { jm.unregisterAllServices() }
            runCatching { jm.close() }
        }
        jmDNS = null
        runCatching {
            if (multicastLock?.isHeld == true) multicastLock?.release()
        }
        multicastLock = null
    }

    private fun emit(gen: Int, state: State) {
        ui.post { if (gen == generation.get()) onState(state) }
    }
}
