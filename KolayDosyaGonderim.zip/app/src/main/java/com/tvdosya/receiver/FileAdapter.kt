package com.tvdosya.receiver

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FileAdapter(
    private val items: MutableList<ReceivedFile>,
    private val onAction: (ReceivedFile) -> Unit,
    private val onDelete: (ReceivedFile) -> Unit
) : RecyclerView.Adapter<FileAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
        val action: Button = v.findViewById(R.id.action)
        val delete: Button = v.findViewById(R.id.delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val f = items[position]
        holder.title.text = f.name
        holder.sub.text = "${f.humanSize()}   •   ${f.humanTime()}"

        val (glyph, bg) = when (f.kind) {
            ReceivedFile.Kind.APK -> R.drawable.ic_apk to R.drawable.bg_icon_apk
            ReceivedFile.Kind.VIDEO -> R.drawable.ic_video to R.drawable.bg_icon_video
            ReceivedFile.Kind.IMAGE -> R.drawable.ic_image to R.drawable.bg_icon_image
            ReceivedFile.Kind.PDF -> R.drawable.ic_doc to R.drawable.bg_icon_pdf
            ReceivedFile.Kind.AUDIO -> R.drawable.ic_audio to R.drawable.bg_icon_audio
            ReceivedFile.Kind.OTHER -> R.drawable.ic_doc to R.drawable.bg_icon_other
        }
        holder.icon.setImageResource(glyph)
        holder.icon.setBackgroundResource(bg)
        holder.action.text =
            if (f.kind == ReceivedFile.Kind.APK) "Kur" else holder.action.context.getString(R.string.open)

        holder.action.setOnClickListener { onAction(f) }
        holder.delete.setOnClickListener { onDelete(f) }

        // Satırdaki iki butondan biri odaklandığında satır bütün olarak öne çıkar.
        val fl = View.OnFocusChangeListener { _, _ ->
            holder.itemView.post { lift(holder.itemView, holder.action.hasFocus() || holder.delete.hasFocus()) }
        }
        holder.action.onFocusChangeListener = fl
        holder.delete.onFocusChangeListener = fl
        lift(holder.itemView, holder.action.hasFocus() || holder.delete.hasFocus())
    }

    private fun lift(v: View, focused: Boolean) {
        v.animate()
            .scaleX(if (focused) 1.025f else 1f)
            .scaleY(if (focused) 1.025f else 1f)
            .translationZ(if (focused) 16f else 0f)
            .setDuration(160)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    fun addFirst(f: ReceivedFile) {
        items.add(0, f)
        notifyItemInserted(0)
    }

    fun remove(f: ReceivedFile) {
        val i = items.indexOf(f)
        if (i >= 0) {
            items.removeAt(i)
            notifyItemRemoved(i)
        }
    }

    fun snapshot(): List<ReceivedFile> = items.toList()
}
