package com.tvdosya.receiver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private var done = false
    private lateinit var video: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_splash)

        video = findViewById(R.id.video)
        video.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        try {
            video.setVideoURI(
                Uri.parse("android.resource://$packageName/${R.raw.intro}")
            )
            video.setOnPreparedListener { mp -> mp.setVolume(1f, 1f) }
            video.setOnCompletionListener { goMain() }
            video.setOnErrorListener { _, _, _ -> goMain(); true }
            video.start()
        } catch (_: Exception) {
            goMain()
        }
    }

    private fun goMain() {
        if (done) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    /** Kumandada herhangi bir tuş açılışı atlar. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        goMain()
        return true
    }

    override fun onPause() {
        super.onPause()
        if (video.isPlaying) video.pause()
    }

    override fun onDestroy() {
        try { video.stopPlayback() } catch (_: Exception) {}
        super.onDestroy()
    }
}
