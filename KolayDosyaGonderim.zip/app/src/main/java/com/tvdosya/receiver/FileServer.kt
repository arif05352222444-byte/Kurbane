package com.tvdosya.receiver

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream

class FileServer(
    private val context: Context,
    port: Int,
    private val onFileReceived: (ReceivedFile) -> Unit
) : NanoHTTPD(port) {

    companion object {
        const val FOLDER = "KolayDosya"
        /** Apple Kestirmesi bu portu kullandığı için sabittir. */
        const val PORT = 8080
    }

    override fun serve(session: IHTTPSession): Response {
        return try {
            when {
                session.method == Method.POST && session.uri == "/upload" -> handleUpload(session)
                session.uri == "/ping" -> newFixedLengthResponse(Response.Status.OK, "text/plain", "OK")
                session.uri == "/yardim.jpg" || session.uri == "/nedir.jpg" ||
                    session.uri == "/ikon.jpg" ->
                    newChunkedResponse(
                        Response.Status.OK,
                        "image/jpeg",
                        context.assets.open(session.uri.removePrefix("/"))
                    )
                else -> newFixedLengthResponse(Response.Status.OK, "text/html", page())
            }
        } catch (e: Exception) {
            newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "HATA: ${e.message}")
        }
    }

    private fun handleUpload(session: IHTTPSession): Response {
        val files = HashMap<String, String>()
        session.parseBody(files)

        var count = 0
        for ((key, tmpPath) in files) {
            val original = session.parameters[key]?.firstOrNull() ?: "dosya_${System.currentTimeMillis()}"
            val name = safeName(original)
            val tmp = File(tmpPath)
            if (!tmp.exists() || tmp.length() == 0L) continue
            val size = tmp.length()
            val saved = saveFile(tmp, name)
            onFileReceived(
                ReceivedFile(name, size, System.currentTimeMillis(), saved.first, saved.second)
            )
            count++
        }
        return newFixedLengthResponse(
            Response.Status.OK, "text/plain",
            if (count > 0) "OK:$count" else "BOS"
        )
    }

    private fun safeName(raw: String): String {
        val cleaned = raw.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^A-Za-z0-9._\\-çğıöşüÇĞİÖŞÜ ]"), "_")
        return if (cleaned.isBlank()) "dosya_${System.currentTimeMillis()}" else cleaned
    }

    /** Dosyayı kaydeder; (uri, dosya yolu) döner. Yol yalnızca doğrudan yazımda dolu olur. */
    private fun saveFile(tmp: File, name: String): Pair<String, String> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mimeOf(name))
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
            }
            val uri: Uri? = context.contentResolver
                .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out -> copy(tmp, out) }
                return uri.toString() to ""
            }
        }
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            FOLDER
        )
        if (!dir.exists()) dir.mkdirs()
        var target = File(dir, name)
        var i = 1
        while (target.exists()) {
            val base = name.substringBeforeLast('.', name)
            val ext = name.substringAfterLast('.', "")
            target = File(dir, if (ext.isEmpty()) "${base}_$i" else "${base}_$i.$ext")
            i++
        }
        target.outputStream().use { out -> copy(tmp, out) }
        val uriStr = try {
            FileProvider.getUriForFile(
                context, context.packageName + ".fileprovider", target
            ).toString()
        } catch (_: Exception) {
            Uri.fromFile(target).toString()
        }
        return uriStr to target.absolutePath
    }

    private fun copy(src: File, out: OutputStream) {
        FileInputStream(src).use { input ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val r = input.read(buf)
                if (r <= 0) break
                out.write(buf, 0, r)
            }
            out.flush()
        }
    }

    private fun mimeOf(name: String): String {
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "heic" -> "image/heic"
            "webp" -> "image/webp"
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "pdf" -> "application/pdf"
            "apk" -> "application/vnd.android.package-archive"
            "zip" -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    private fun page(): String = context.assets.open("upload.html")
        .bufferedReader().use { it.readText() }
}
